Configuration DC
{
    Import-DSCResource -ModuleName StorageDsc -ModuleVersion 4.1.0.0

    Node localhost
    {
        WaitForDisk Disk2
        {
             DiskId = 2
             RetryIntervalSec = 60
             RetryCount = 60
        }

        Disk FVolume
        {
             DiskId = 2
             DriveLetter = 'F'
             DependsOn = '[WaitForDisk]Disk2'
        }
      
    }
}
