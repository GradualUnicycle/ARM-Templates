﻿configuration DC 
{ 
   param 
   ( 
        [parameter(Mandatory)]
        [string]$MachineName,
        
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds

    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, StorageDSC, xNetworking, PSDesiredStateConfiguration
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node $MachineName
    {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

	    WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"		
        }

        #Script EnableDNSDiags
	    #{
      	#    SetScript = { 
		#        Set-DnsServerDiagnostics -All $true
        #        Write-Verbose -Verbose "Enabling DNS client diagnostics" 
        #    }
        #    GetScript =  { @{} }
        #    TestScript = { $false }
	    #    DependsOn = "[WindowsFeature]DNS"
        #}

	    WindowsFeature DnsTools
	    {
	        Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
	    }

        #xDnsServerAddress DnsServerAddress 
        #{ 
        #    Address        = '127.0.0.1' 
        #    InterfaceAlias = $InterfaceAlias
        #    AddressFamily  = 'IPv4'
	    #    DependsOn = "[WindowsFeature]DNS"
        #}

        WaitForDisk Disk2
        {
             DiskId = 2
             RetryIntervalSec = 60
             RetryCount = 60
        }

        Disk FVolume
        {
             DiskId = 2
             DriveLetter = 'F'
             DependsOn = '[WaitForDisk]Disk2'
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
	        DependsOn="[WindowsFeature]DNS" 
        } 

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
         
        #xADDomain CreateForest 
        #{
        #    DomainName = $DomainName
        #    DomainAdministratorCredential = $DomainCreds
        #    SafemodeAdministratorPassword = $DomainCreds
        #    DatabasePath = "F:\NTDS"
        #    LogPath = "F:\NTDS"
        #    SysvolPath = "F:\SYSVOL"
	    #    DependsOn = @("[Disk]FVolume", "[WindowsFeature]ADDSInstall")
        #} 

   }
}
DC 
