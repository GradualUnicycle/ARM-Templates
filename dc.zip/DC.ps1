Configuration DC{
    param (
        $MachineName
    )
    Import-DSCResource -ModuleName StorageDsc,psdisredstateconfiguration, xactivedirectory

    Node $MachineName
    {

        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        WaitForDisk Disk2
        {
             DiskId = 2
             RetryIntervalSec = 60
             RetryCount = 60
        }

        Disk FVolume
        {
             DiskId = 2
             DriveLetter = 'F'
             DependsOn = '[WaitForDisk]Disk2'
        }

        WindowsFeature DNS {
            Ensure = 'Present'
            Name = 'DNS'
        }

        WindowsFeature ADDSInstall {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature ADDSTools {
            Ensure = 'Present'
            Name = 'RSAT-ADDS-Tools'
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter {
            Ensure = 'Present'
            Name = 'RSAT-AD-AdminCenter'
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
      
    }
}
